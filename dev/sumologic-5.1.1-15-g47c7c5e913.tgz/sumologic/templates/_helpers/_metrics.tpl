{{/*
Check if any metrics provider is enabled
Example Usage:
{{- if eq (include "metrics.enabled" .) "true" }}

*/}}
{{- define "metrics.enabled" -}}
{{- $enabled := false -}}
{{- if eq (include "metrics.otelcol.enabled" .) "true" }}
{{- $enabled = true -}}
{{- end -}}
{{ $enabled }}
{{- end -}}


{{/*
Check if otelcol metrics provider is enabled
Example Usage:
{{- if eq (include "metrics.otelcol.enabled" .) "true" }}

*/}}
{{- define "metrics.otelcol.enabled" -}}
{{- $enabled := false -}}
{{- if and (eq .Values.sumologic.metrics.enabled true) (eq .Values.metadata.metrics.enabled true) -}}
{{- $enabled = true -}}
{{- end -}}
{{ $enabled }}
{{- end -}}

{{/*
Generate list of remoteWrite endpoints for telegraf configuration

'{{ include "metric.endpoints" . }}'
*/}}
{{- define "metric.endpoints" -}}
{{- $endpoints := list -}}
{{- range $endpoint := .Values.metadata.metrics.config.additionalEndpoints }}
{{- $endpoints = append $endpoints ($endpoint | quote) -}}
{{- end -}}
{{- $endpoints := uniq $endpoints -}}
{{- $endpoints := sortAlpha $endpoints -}}
{{ $endpoints | join ",\n" }}
{{- end -}}

{{/*
Return the otelcol metrics collector image
*/}}
{{- define "sumologic.metrics.collector.image" -}}
{{ template "utils.getOtelImage" (dict "overrideImage" .Values.sumologic.metrics.collector.otelcol.image "defaultImage" .Values.sumologic.otelcolImage) }}
{{- end -}}

{{/*
Check if single-layer pipeline for metrics collector is enabled.
When true, the collector handles both scraping and enrichment, eliminating the metadata layer.

Example Usage:
{{- if eq (include "metrics.collector.singleLayerPipeline.enabled" .) "true" }}
*/}}
{{- define "metrics.collector.singleLayerPipeline.enabled" -}}
{{- $enabled := false -}}
{{- if and (eq (include "metrics.otelcol.enabled" .) "true") .Values.sumologic.metrics.collector.otelcol.enabled .Values.sumologic.metrics.collector.otelcol.singleLayerPipeline.enabled -}}
{{- $enabled = true -}}
{{- end -}}
{{ $enabled }}
{{- end -}}

{{- define "metrics.collector.otelcol.nodeSelector" -}}
{{- template "nodeSelector" (dict "Values" .Values "nodeSelector" .Values.sumologic.metrics.collector.otelcol.nodeSelector)}}
{{- end -}}

{{- define "metrics.collector.otelcol.serviceMonitorSelector" -}}
{{- if .Values.sumologic.metrics.collector.otelcol.serviceMonitorSelector -}}
{{- toYaml .Values.sumologic.metrics.collector.otelcol.serviceMonitorSelector -}}
{{- end -}}
{{- end -}}

{{- define "metrics.collector.otelcol.podMonitorSelector" -}}
{{- if .Values.sumologic.metrics.collector.otelcol.podMonitorSelector -}}
{{- toYaml .Values.sumologic.metrics.collector.otelcol.podMonitorSelector -}}
{{- end -}}
{{- end -}}

{{- define "metrics.collector.otelcol.tolerations" -}}
{{- if .Values.sumologic.metrics.collector.otelcol.tolerations -}}
{{- toYaml .Values.sumologic.metrics.collector.otelcol.tolerations -}}
{{- else -}}
{{- template "kubernetes.defaultTolerations" . -}}
{{- end -}}
{{- end -}}

{{- define "sumologic.metrics.collector.otelcol.managementState" -}}
{{printf "managed"}}
{{- end -}}

{{- define "sumologic.metrics.collector.otelcol.upgradeStrategy" -}}
{{printf "automatic"}}
{{- end -}}

{{- define "metrics.collector.otelcol.affinity" -}}
{{- if .Values.sumologic.metrics.collector.otelcol.affinity -}}
{{- toYaml .Values.sumologic.metrics.collector.otelcol.affinity -}}
{{- else -}}
{{- template "kubernetes.defaultAffinity" . -}}
{{- end -}}
{{- end -}}

{{- define "metadata.metrics.statefulset.nodeSelector" -}}
{{- template "nodeSelector" (dict "Values" .Values "nodeSelector" .Values.metadata.metrics.statefulset.nodeSelector)}}
{{- end -}}

{{- define "metadata.metrics.statefulset.tolerations" -}}
{{- if .Values.metadata.metrics.statefulset.tolerations -}}
{{- toYaml .Values.metadata.metrics.statefulset.tolerations -}}
{{- else -}}
{{- template "kubernetes.defaultTolerations" . -}}
{{- end -}}
{{- end -}}

{{- define "metadata.metrics.statefulset.affinity" -}}
{{- if .Values.metadata.metrics.statefulset.affinity -}}
{{- toYaml .Values.metadata.metrics.statefulset.affinity -}}
{{- else -}}
{{- template "kubernetes.defaultAffinity" . -}}
{{- end -}}
{{- end -}}

{{- define "sumologic.labels.app.metrics" -}}
{{ template "sumologic.labels.app.otelcol" . }}-metrics
{{- end -}}

{{- define "sumologic.labels.app.metrics.pod" -}}
{{- template "sumologic.labels.app.metrics" . }}
{{- end -}}

{{- define "sumologic.labels.app.metrics.service" -}}
{{- template "sumologic.labels.app.metrics" . }}
{{- end -}}

{{- define "sumologic.labels.app.metrics.service-headless" -}}
{{- template "sumologic.labels.app.metrics.service" . }}-headless
{{- end -}}

{{- define "sumologic.labels.app.metrics.configmap" -}}
{{- template "sumologic.labels.app.metrics" . }}
{{- end -}}

{{- define "sumologic.labels.app.metrics.statefulset" -}}
{{- template "sumologic.labels.app.metrics" . }}
{{- end -}}

{{- define "sumologic.labels.app.metrics.hpa" -}}
{{- template "sumologic.labels.app.metrics" . }}
{{- end -}}

{{- define "sumologic.metadata.name.metrics" -}}
{{ template "sumologic.metadata.name.otelcol" . }}-metrics
{{- end -}}

{{- define "sumologic.metrics.metadata.endpoint" -}}
{{ template "sumologic.metadata.name.metrics.service" . }}
{{- end -}}

{{- define "sumologic.metadata.name.metrics.service" -}}
{{ template "sumologic.fullname" . }}-metadata-metrics
{{- end -}}

{{- define "sumologic.metadata.name.metrics.service-headless" -}}
{{ template "sumologic.metadata.name.metrics" . }}-headless
{{- end -}}

{{- define "sumologic.metadata.name.metrics.configmap" -}}
{{ template "sumologic.metadata.name.metrics" . }}
{{- end -}}

{{- define "sumologic.metadata.name.metrics.statefulset" -}}
{{ template "sumologic.metadata.name.metrics" . }}
{{- end -}}

{{- define "sumologic.metadata.name.metrics.pdb" -}}
{{ template "sumologic.metadata.name.metrics.statefulset" . }}-pdb
{{- end -}}

{{- define "sumologic.metadata.name.metrics.hpa" -}}
{{- template "sumologic.metadata.name.metrics" . }}
{{- end -}}


{{- define "sumologic.labels.metrics" -}}
sumologic.com/app: otelcol-metrics
sumologic.com/component: metrics
{{- end -}}

{{- define "sumologic.label.scrape" -}}
sumologic.com/scrape: "true"
{{- end -}}

{{- define "sumologic.labels.scrape.metrics" -}}
{{ template "sumologic.label.scrape" . }}
{{ template "sumologic.labels.metrics" . }}
{{- end -}}

{{- define "sumologic.metadata.name.pvcCleaner.metrics" -}}
{{- template "sumologic.metadata.name.pvcCleaner" . }}-metrics
{{- end -}}

{{- define "sumologic.labels.app.pvcCleaner.metrics" -}}
{{- template "sumologic.labels.app.pvcCleaner" . }}-metrics
{{- end -}}

{{/*
Definitions for metrics collector
*/}}

{{- define "sumologic.labels.component.metrics" -}}
sumologic.com/component: metrics
{{- end -}}

{{- define "sumologic.labels.app.metrics.collector" -}}
sumologic.com/app: otelcol
{{- end -}}

{{- define "sumologic.labels.metrics.clusterrole" -}}
{{- template "sumologic.labels.component.metrics" . }}
{{- end -}}

{{- define "sumologic.labels.metrics.clusterrolebinding" -}}
{{- template "sumologic.labels.component.metrics" . }}
{{- end -}}

{{- define "sumologic.labels.metrics.serviceaccount" -}}
{{- template "sumologic.labels.component.metrics" . }}
{{- end -}}

{{- define "sumologic.labels.metrics.opentelemetrycollector" -}}
{{ template "sumologic.labels.app.metrics.collector" . }}
{{ template "sumologic.labels.component.metrics" . }}
{{- end -}}

{{- define "sumologic.metadata.name.metrics.collector" -}}
{{- template "sumologic.fullname" . }}-metrics
{{- end -}}

{{- define "sumologic.metadata.name.metrics.collector.opentelemetrycollector" -}}
{{ template "sumologic.metadata.name.metrics.collector" . }}
{{- end -}}

{{- define "sumologic.metadata.name.metrics.collector.serviceaccount" -}}
{{ template "sumologic.metadata.name.metrics.collector" . }}
{{- end -}}

{{- define "sumologic.metadata.name.metrics.collector.clusterrole" -}}
{{ template "sumologic.metadata.name.metrics.collector" . }}
{{- end -}}

{{- define "sumologic.metadata.name.metrics.collector.clusterrolebinding.prometheus" -}}
{{ template "sumologic.metadata.name.metrics.collector" . }}-prometheus
{{- end -}}

{{- define "sumologic.metadata.name.metrics.collector.clusterrolebinding.metadata" -}}
{{ template "sumologic.metadata.name.metrics.collector" . }}-metadata
{{- end -}}

{{- define "sumologic.metadata.name.metrics.targetallocator.name" -}}
{{ template "sumologic.metadata.name.metrics.collector.opentelemetrycollector" . }}-targetallocator
{{- end -}}

{{/*
The `-sa` suffix at the end is needed to differentiate from the ServiceAccount created by the OpenTelemetry Operator.
We ended up deferring to the operator on this, and then had to walk this decision back, as we needed to attach our own pull secrets to this ServiceAccount.
However, this created a conflict where Helm didn't want to overwrite the SA created by the operator. To get around this, the name was changed.
*/}}
{{- define "sumologic.metadata.name.metrics.targetallocator.serviceaccount" -}}
{{ template "sumologic.metadata.name.metrics.targetallocator.name" . }}-sa
{{- end -}}

{{- define "sumologic.metadata.name.metrics.targetallocator.clusterrole" -}}
{{ template "sumologic.metadata.name.metrics.targetallocator.name" . }}
{{- end -}}

{{- define "sumologic.metadata.name.metrics.targetallocator.clusterrolebinding" -}}
{{ template "sumologic.metadata.name.metrics.targetallocator.name" . }}
{{- end -}}

{{/*
Return the metrics format for the default Sumologic exporter for metrics.
'{{ include "metrics.otelcol.exporter.format" . }}'
*/}}
{{- define "metrics.otelcol.exporter.format" -}}
{{- if eq .Values.sumologic.metrics.sourceType "http" -}}
{{- "prometheus" -}}
{{- else if eq .Values.sumologic.metrics.sourceType "otlp" -}}
{{- "otlp" -}}
{{- else -}}
{{- fail "`sumologic.metrics.sourceType` can only be `http` or `otlp`" -}}
{{- end -}}
{{- end -}}

{{/*
Return the endpoint for the default Sumologic exporter for metrics.
'{{ include "metrics.otelcol.exporter.endpoint" . }}'
*/}}
{{- define "metrics.otelcol.exporter.endpoint" -}}
{{- if eq .Values.sumologic.metrics.sourceType "http" -}}
{{- "${SUMO_ENDPOINT_DEFAULT_METRICS_SOURCE}" -}}
{{- else if eq .Values.sumologic.metrics.sourceType "otlp" -}}
{{- "${SUMO_ENDPOINT_DEFAULT_OTLP_METRICS_SOURCE}" -}}
{{- else -}}
{{- fail "`sumologic.metrics.sourceType` can only be `http` or `otlp`" -}}
{{- end -}}
{{- end -}}

{{/*
Check if autoscaling for metadata metrics is enabled.

Example Usage:
{{- if eq (include "metadata.metrics.autoscaling.enabled" .) "true" }}

*/}}
{{- define "metadata.metrics.autoscaling.enabled" -}}
{{- template "is.autoscaling.enabled" (dict "autoscalingEnabled" .Values.metadata.metrics.autoscaling.enabled "Values" .Values) -}}
{{- end -}}

{{/*
Check if autoscaling for metrics collector is enabled.

Example Usage:
{{- if eq (include "metrics.collector.autoscaling.enabled" .) "true" }}

*/}}
{{- define "metrics.collector.autoscaling.enabled" -}}
{{- template "is.autoscaling.enabled" (dict "autoscalingEnabled" .Values.sumologic.metrics.collector.otelcol.autoscaling.enabled "Values" .Values) -}}
{{- end -}}

{{/*
Returns list of namespaces to exclude

Example:

{{ include "metrics.excludeNamespaces" . }}
*/}}
{{- define "metrics.excludeNamespaces" -}}
{{- $excludeNamespaceRegex := .Values.sumologic.metrics.excludeNamespaceRegex | quote -}}
{{- if eq .Values.sumologic.collectionMonitoring false -}}
  {{- if .Values.sumologic.metrics.excludeNamespaceRegex -}}
  {{- $excludeNamespaceRegex = printf "%s|%s" ( include "sumologic.namespace" .  ) .Values.sumologic.metrics.excludeNamespaceRegex | quote -}}
  {{- else -}}
  {{- $excludeNamespaceRegex = printf "%s" ( include "sumologic.namespace" .  ) | quote -}}
  {{- end -}}
{{- end -}}
{{ print $excludeNamespaceRegex }}
{{- end -}}

{{- define "metrics.collector.files.list" -}}
- /var/log/pods/{{ template "sumologic.namespace" . }}_{{ template "sumologic.metadata.name.metrics.collector" . }}*/*/*.log
{{- end -}}

{{- define "metrics.metadata.files.list" -}}
- /var/log/pods/{{ template "sumologic.namespace" . }}_{{ template "sumologic.metadata.name.metrics.statefulset" . }}*/*/*.log
{{- end -}}
